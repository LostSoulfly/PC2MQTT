# BadLogger

A bad but simple logger. Uses serilog.


```
//Reference BadLogger.dll in your project, and add it's using line:
using BadLogger;

//Declare your BadLogger object in each class or form:
private BadLogger.BadLogger Log;

//Setup the event handler:
BadLogger.EventSink.OnLogEvent += EventSink_OnLogEvent;


private Delegate EventSink_OnLogEvent(string log)
{
    richTextLog.Text += log + Environment.NewLine;
    return null;
}


//Configure the log level:
LogManager.SetMinimumLogLevel("VERBOSE");

"VERBOSE" or "VERB"
"DEBUG"
"INFORMATION" or "INFO"
"WARNING" or "WARN"
"ERROR"
"FATAL"

//Initialize the logger for each class or form you will use it in:
Log = LogManager.GetCurrentClassLogger();

//Ignore log messages from certain classes if desired (copy+paste from log output to get the exact string):
//This uses a hashset, so it's not going to work with wildcards.
LogManager.IgnoreLogClass("ProgramName.formMain+<Form1_Load>d__5");

//Use it:
Log.Info("Hello world!");
Log.Warn("Hello world!");
Log.Error("Hello world!");
etc
```